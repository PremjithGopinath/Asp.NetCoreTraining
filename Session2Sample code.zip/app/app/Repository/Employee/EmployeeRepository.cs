﻿using System.Collections.Generic;
using System.Linq;
using EmployeeType = app.Models.Employee;

namespace app.Repository.Employee
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private List<EmployeeType> EmployeeList;

        public EmployeeRepository()
        {
            EmployeeList = new List<EmployeeType>()
            {
                new EmployeeType
                {
                    Id = 1,
                    Name = "Prem",
                    Age = 22,
                    Address = "Address 1",
                },
                new EmployeeType
                {
                    Id = 2,
                    Name = "Sree",
                    Age = 23,
                    Address = "Address 2",
                }
            };
        }

        public List<EmployeeType> Get()
        {
            return EmployeeList;
        }

        public EmployeeType Get(int id)
        {
            return EmployeeList.Where(s => s.Id == id).SingleOrDefault();
        }
    }
}
