﻿using System.Collections.Generic;
using EmployeeType = app.Models.Employee;

namespace app.Repository.Employee
{
    public interface IEmployeeRepository
    {
        List<EmployeeType> Get();
        EmployeeType Get(int id);
    }
}
