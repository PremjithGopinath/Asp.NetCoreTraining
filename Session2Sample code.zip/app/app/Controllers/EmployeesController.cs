﻿using app.Models;
using app.Repository.Employee;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace app.Controllers
{
    //[Route("api/[controller]")]
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeesController : Controller
    {
        private IEmployeeRepository EmployeeRepository;

        public EmployeesController(IEmployeeRepository employeeRepository)
        {
            //EmployeeRepository = new EmployeeRepository();
            EmployeeRepository = employeeRepository;
        }

        // GET: api/values
        [HttpGet]
        [HttpGet("list")]
        public IEnumerable<Employee> Get()
        {
            return EmployeeRepository.Get();
        }

        // GET: api/values/5
        [HttpGet("{id}")]
        public Employee Get(int id)
        {
            return EmployeeRepository.Get(id);
        }
    }
}
