﻿using app.Middlewares;
using app.Repository.Employee;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;

namespace app
{
    public class Startup
    {
        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc();
            services.AddSingleton<IEmployeeRepository, EmployeeRepository>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            //if (env.IsDevelopment())
            //{
            //    app.UseDeveloperExceptionPage();
            //}

            app.UseCustomMiddleware();

            //app.UseMiddleware<CustomMiddleware>();

            app.UseDefaultFiles();
            app.UseStaticFiles();

            app.UseMvc();

            //app.UseAuthentication();



            //app.Use(async (context, next) =>
            //{
            //    await context.Response.WriteAsync("Middleware1: Incoming Request\n");
            //    await next();
            //    await context.Response.WriteAsync("Middleware1: Outgoing Response\n");
            //});

            //app.Use(async (context, next) =>
            //{
            //    await context.Response.WriteAsync("Middleware2: Incoming Request\n");
            //    await next();
            //    await context.Response.WriteAsync("Middleware2: Outgoing Response\n");
            //});

            //app.Run(async (context) =>
            //{
            //   await context.Response.WriteAsync("Middleware3: Incoming Request handled and response generated\n");
            //});

            //Used for default routing in asp.net core mvc 3 and above
            //app.UseRouting();
            //app.UseEndpoints(endpoints =>
            //{
            //    // Default route
            //    endpoints.MapControllerRoute(
            //        name: "default",
            //        pattern: "{controller=Home}/{action=Index}/{id?}");
            //});
        }
    }
}
